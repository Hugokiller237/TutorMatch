<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alumno extends Model
{
    use HasFactory;

    protected $fillable = [
        'nombre',
        'email',
        'foto',
        'tutor_id',
        'curso_escolar',
        'anio_escolar',
        'tiempo_estancia',
        'en_empresa',
    ];

    protected $casts = [
        'en_empresa' => 'boolean',
    ];

    public function tutor()
    {
        return $this->belongsTo(Tutor::class);
    }

    public function alumnos()
    {
        return $this->hasMany(Alumno::class);
    }


    public function asignacion()
    {
        return $this->hasOne(Asignacion::class);
    }
}
