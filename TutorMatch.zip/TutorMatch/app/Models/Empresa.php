<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empresa extends Model
{
    use HasFactory;

    protected $table = 'empresas';

    protected $fillable = [
        'nombre',
        'email',
        'representante_legal',
        'telefono_representante_legal',
        'dni_representante_legal',
        'cif',
        'tutor_laboral',
        'dni_tutor_laboral',
        'telefono_tutor_laboral',
        'domicilio',
    ];

    public function asignaciones()
    {
        return $this->hasMany(Asignacion::class);
    }
}
