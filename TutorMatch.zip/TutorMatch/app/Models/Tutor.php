<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Tutor extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $table = 'tutores';

    protected $fillable = ['nombre', 'email', 'password', 'foto', 'rol'];

    protected $hidden = ['password'];

    public function alumnos()
    {
        return $this->hasMany(Alumno::class);
    }

    public function asignaciones()
    {
        return $this->hasMany(Asignacion::class);
    }
}
