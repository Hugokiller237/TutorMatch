<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Asignacion extends Model
{
    use HasFactory;
    protected $table = 'asignaciones';

    protected $fillable = ['alumno_id', 'empresa_id', 'tutor_id', 'fecha_asignacion'];

    public function alumno()
    {
        return $this->belongsTo(Alumno::class);
    }

    public function empresa()
    {
        return $this->belongsTo(Empresa::class);
    }

    public function tutor()
    {
        return $this->belongsTo(Tutor::class);
    }
}