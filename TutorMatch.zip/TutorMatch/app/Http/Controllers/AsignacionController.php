<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\Asignacion;
use App\Models\Empresa;
use App\Models\Tutor;

class AsignacionController extends Controller
{

    public function vistaLista()
    {
        $tutorId = Session::get('tutor_id');
        if (!$tutorId) {
            return redirect('/iniciar-sesion');
        }

        $asignaciones = Asignacion::with(['alumno', 'empresa'])
            ->where('tutor_id', $tutorId)
            ->get();

        $tutor = auth()->user() ?? Session::get('tutor'); // Ajusta según cómo manejes sesión

        return view('listaAsignaciones', compact('asignaciones', 'tutor'));
    }

    public function vistaAsignarEmpresa($id)
    {
        $asignacion = Asignacion::with('alumno')->findOrFail($id);
        $empresas = Empresa::all();

        return view('asignarEmpresa', compact('asignacion', 'empresas'));
    }

    public function formAsignar($id)
    {
        $tutorId = Session::get('tutor_id');

        if (!$tutorId) {
            return redirect('/iniciar-sesion');
        }

        $asignacion = Asignacion::with('alumno')->where('id', $id)->where('tutor_id', $tutorId)->first();

        if (!$asignacion) {
            return redirect('/asignaciones')->with('error', 'Asignación no encontrada');
        }

        $empresas = Empresa::all();
        $tutor = Tutor::find($tutorId);

        return view('asignarEmpresa', compact('asignacion', 'empresas', 'tutor'));
    }


    // Listar asignaciones del tutor autenticado
    public function index()
    {
        $tutorId = Session::get('tutor_id');

        if (!$tutorId) {
            return response()->json(['message' => 'Tutor no autenticado'], 401);
        }

        $asignaciones = Asignacion::with(['alumno', 'empresa'])
            ->where('tutor_id', $tutorId)
            ->get();

        return response()->json($asignaciones, 200);
    }

    public function asignarEmpresa(Request $request, $asignacionId)
    {
        $tutorId = Session::get('tutor_id');

        if (!$tutorId) {
            return response()->json(['message' => 'Tutor no autenticado'], 401);
        }

        $asignacion = Asignacion::where('id', $asignacionId)
            ->where('tutor_id', $tutorId)
            ->first();

        if (!$asignacion) {
            return response()->json(['message' => 'Asignación no encontrada o no autorizada'], 404);
        }

        if ($request->input('accion') === 'quitar') {
            // Quitar empresa
            $asignacion->empresa_id = null;
            $asignacion->fecha_asignacion = null;
            $asignacion->save();

            // Marcar alumno como no asignado
            $alumno = $asignacion->alumno;
            $alumno->en_empresa = false;
            $alumno->save();

            return redirect('/asignaciones')->with('success', 'Empresa quitada correctamente');
        }

        // Validar y asignar empresa
        $request->validate([
            'empresa_id' => 'required|exists:empresas,id',
        ]);

        $asignacion->empresa_id = $request->empresa_id;
        $asignacion->fecha_asignacion = now();
        $asignacion->save();

        // Actualizar estado del alumno
        $alumno = $asignacion->alumno;
        $alumno->en_empresa = true;
        $alumno->save();

        return redirect('/asignaciones')->with('success', 'Empresa asignada correctamente');
    }


}
