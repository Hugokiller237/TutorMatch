<?php

namespace App\Http\Controllers;

use App\Models\Tutor;
use App\Models\Alumno;
use App\Models\Asignacion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class TutorController extends Controller
{
    /**
     * Iniciar sesión del tutor.
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $tutor = Tutor::where('email', $request->email)->first();

        if ($tutor && Hash::check($request->password, $tutor->password)) {
            Session::put('tutor_id', $tutor->id);
            return redirect('/');
        } else {
            return response()->json(['message' => 'Credenciales incorrectas'], 401);
        }
    }

    /**
     * Cerrar sesión del tutor.
     */
    public function logout()
    {
        Session::forget('tutor_id');
        return redirect('/');
    }

    public function editar()
    {
        $tutor = Tutor::find(Session::get('tutor_id'));

        if (!$tutor) {
            return redirect('/')->with('error', 'No se pudo cargar el perfil.');
        }

        return view('editarPerfil', compact('tutor'));
    }


    /**
     * Editar el perfil del tutor autenticado.
     */
    public function update(Request $request)
    {
        $tutor = Tutor::find(Session::get('tutor_id'));

        if (!$tutor) {
            return response()->json(['message' => 'Tutor no autenticado'], 401);
        }

        $request->validate([
            'nombre' => 'nullable|string|max:255',
            'email' => 'nullable|email|unique:tutores,email,' . $tutor->id,
            'password' => 'nullable|string|min:6|confirmed',
            'foto' => 'nullable|image|max:2048'
        ]);

        if ($request->filled('nombre')) {
            $tutor->nombre = $request->nombre;
        }

        if ($request->filled('email')) {
            $tutor->email = $request->email;
        }

        if ($request->filled('password')) {
            $tutor->password = Hash::make($request->password);
        }

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_tutores'), $filename);
            $tutor->foto = $filename;
        }

        $tutor->save();

        return redirect('/')->with('success', 'Perfil actualizado correctamente');
    }

    public function showRegisterForm()
    {
        return view('registrarse');
    }

    public function register(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:tutores,email',
            'password' => 'required|string|min:6|confirmed',
            'foto' => 'nullable|image|max:2048'
        ]);

        $tutor = new Tutor();
        $tutor->nombre = $request->nombre;
        $tutor->email = $request->email;
        $tutor->password = bcrypt($request->password);
        $tutor->rol = 'admin';

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_tutores'), $filename);
            $tutor->foto = $filename;
        }

        $tutor->save();

        // Auto-login tras registro
        \Session::put('tutor_id', $tutor->id);

        return redirect('/');
    }


    //Administrador
    public function index(Request $request)
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin') {
            return abort(403);
        }

        $query = Tutor::query(); // Quitamos el where('id', '!=', $admin->id)

        if ($request->filled('buscar')) {
            $query->where('nombre', 'LIKE', '%' . $request->buscar . '%');
        }

        $tutores = $query->get();

        return view('listaTutores', compact('tutores', 'admin')); // Pasamos $admin a la vista
    }



    public function create()
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin')
            return abort(403);
        return view('crearTutor');
    }

    public function store(Request $request)
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin')
            return abort(403);

        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:tutores,email',
            'password' => 'required|string|min:6|confirmed',
            'foto' => 'nullable|image|max:2048'
        ]);

        $tutor = new Tutor();
        $tutor->nombre = $request->nombre;
        $tutor->email = $request->email;
        $tutor->password = Hash::make($request->password);
        $tutor->rol = 'normal';

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_tutores'), $filename);
            $tutor->foto = $filename;
        }

        $tutor->save();
        return redirect()->route('tutores.index')->with('success', 'Tutor creado correctamente.');
    }

    public function edit($id)
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin')
            return abort(403);
        $tutor = Tutor::findOrFail($id);
        return view('editarTutor', compact('tutor'));
    }

    public function updateAdmin(Request $request, $id)
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin')
            return abort(403);

        $tutor = Tutor::findOrFail($id);

        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:tutores,email,' . $tutor->id,
            'password' => 'nullable|string|min:6|confirmed',
            'foto' => 'nullable|image|max:2048'
        ]);

        $tutor->nombre = $request->nombre;
        $tutor->email = $request->email;

        if ($request->filled('password')) {
            $tutor->password = Hash::make($request->password);
        }

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_tutores'), $filename);
            $tutor->foto = $filename;
        }

        $tutor->save();

        return redirect()->route('tutores.index')->with('success', 'Tutor actualizado correctamente.');
    }



    public function verAlumnos($id)
    {
        $admin = Tutor::find(Session::get('tutor_id'));

        if (!$admin || $admin->rol !== 'admin') {
            return abort(403);
        }

        $tutor = Tutor::findOrFail($id);
        $alumnos = $tutor->alumnos()->get();

        // 👉 Esto es lo que faltaba
        $tutores = Tutor::where('id', '!=', $tutor->id)->get();

        return view('alumnosDelTutor', compact('tutor', 'alumnos', 'tutores'));
    }

    public function destroy($id)
    {
        $admin = Tutor::find(Session::get('tutor_id'));
        if (!$admin || $admin->rol !== 'admin') {
            return abort(403);
        }

        $tutor = Tutor::findOrFail($id);

        // No permitir eliminarse a sí mismo
        if ($admin->id === $tutor->id) {
            return redirect()->route('tutores.index')->with('error', 'No puedes eliminar tu propia cuenta.');
        }

        // Verificar si el tutor tiene alumnos asignados
        if ($tutor->alumnos()->count() > 0) {
            return redirect()->route('tutores.index')->with('error', 'No se puede eliminar un tutor con alumnos asignados.');
        }

        $tutor->delete();

        return redirect()->route('tutores.index')->with('success', 'Tutor eliminado correctamente.');
    }


}

