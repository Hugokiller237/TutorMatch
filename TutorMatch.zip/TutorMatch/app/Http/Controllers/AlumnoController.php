<?php

namespace App\Http\Controllers;

use App\Models\Alumno;
use App\Models\Tutor;
use App\Models\Asignacion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AlumnoController extends Controller
{
    /**
     * Listar alumnos del tutor autenticado
     */
    public function index()
    {
        $tutorId = Session::get('tutor_id');

        if (!$tutorId) {
            return response()->json(['message' => 'Tutor no autenticado'], 401);
        }

        $alumnos = Alumno::where('tutor_id', $tutorId)->get();

        return response()->json($alumnos, 200);
    }

    public function vistaLista(Request $request)
    {
        $tutorId = Session::get('tutor_id');

        if (!$tutorId) {
            return redirect('/iniciar-sesion');
        }

        $tutor = Tutor::find($tutorId);

        // Buscar por nombre si hay parámetro 'buscar'
        $busqueda = $request->input('buscar');
        $alumnosQuery = $tutor->alumnos();

        if ($busqueda) {
            $alumnosQuery->where('nombre', 'like', '%' . $busqueda . '%');
        }

        $alumnos = $alumnosQuery->get();

        return view('listaAlumnos', compact('tutor', 'alumnos'));
    }

    /**
     * Crear un nuevo alumno asignado al tutor actual
     */

    public function store(Request $request)
    {
        $authTutor = Tutor::find(Session::get('tutor_id'));

        if (!$authTutor) {
            return response()->json(['message' => 'Tutor no autenticado'], 401);
        }

        // Si es admin y envía un tutor_id válido, lo usamos
        if ($authTutor->rol === 'admin' && $request->filled('tutor_id')) {
            $tutorId = $request->input('tutor_id');
        } else {
            $tutorId = $authTutor->id;
        }


        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:alumnos,email',
            'foto' => 'nullable|image|max:2048',
            'curso_escolar' => 'required|in:1 SMR,2 SMR,1 ASIR,2 ASIR,1 DAW,2 DAW,1 DAM,2 DAM',
            'anio_escolar' => 'required|regex:/^\d{4}-\d{4}$/',
            'tiempo_estancia' => 'required|string|max:255',
        ]);

        $alumno = new Alumno();
        $alumno->nombre = $request->nombre;
        $alumno->email = $request->email;
        $alumno->curso_escolar = $request->curso_escolar;
        $alumno->anio_escolar = $request->anio_escolar;
        $alumno->tiempo_estancia = $request->tiempo_estancia;
        $alumno->en_empresa = false; // siempre false al crearlo
        $alumno->tutor_id = $tutorId;

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_alumnos'), $filename);
            $alumno->foto = $filename;
        }

        $alumno->save();

        // Crear asignación vacía con el alumno
        Asignacion::create([
            'alumno_id' => $alumno->id,
            'tutor_id' => $tutorId,
            'empresa_id' => null,
            'fecha_asignacion' => null
        ]);

        return redirect('/')->with('success', 'Alumno creado con éxito y asignación inicial generada');
    }


    public function edit($id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return redirect('/')->with('error', 'Alumno no encontrado');
        }

        return view('editarAlumno', compact('alumno'));
    }

    public function update(Request $request, $id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return redirect('/')->with('error', 'Alumno no encontrado');
        }

        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:alumnos,email,' . $alumno->id,
            'curso_escolar' => 'required|in:1 SMR,2 SMR,1 ASIR,2 ASIR,1 DAW,2 DAW,1 DAM,2 DAM',
            'anio_escolar' => 'required|regex:/^\d{4}-\d{4}$/',
            'tiempo_estancia' => 'required|string|max:255',
            'foto' => 'nullable|image|max:2048'
        ]);

        $alumno->nombre = $request->nombre;
        $alumno->email = $request->email;
        $alumno->curso_escolar = $request->curso_escolar;
        $alumno->anio_escolar = $request->anio_escolar;
        $alumno->tiempo_estancia = $request->tiempo_estancia;

        if ($request->hasFile('foto')) {
            $filename = time() . '.' . $request->foto->extension();
            $request->foto->move(public_path('fotos_alumnos'), $filename);
            $alumno->foto = $filename;
        }

        $alumno->save();

        return redirect('/')->with('success', 'Alumno actualizado correctamente');
    }





    /**
     * Eliminar un alumno por ID
     */
    public function destroy($id)
    {
        $alumno = Alumno::find($id);

        if (!$alumno) {
            return response()->json(['message' => 'Alumno no encontrado'], 404);
        }

        Asignacion::where('alumno_id', $alumno->id)->delete();
        $alumno->delete();

        return redirect('/')->with('success', 'Alumno eliminado correctamente.');
    }


    public function transferir(Request $request, $id)
    {
        $request->validate([
            'nuevo_tutor_id' => 'required|exists:tutores,id',
        ]);

        $alumno = Alumno::findOrFail($id);
        $alumno->tutor_id = $request->nuevo_tutor_id;
        $alumno->save();

        // También actualizamos la asignación si existe
        if ($alumno->asignacion) {
            $alumno->asignacion->tutor_id = $request->nuevo_tutor_id;
            $alumno->asignacion->save();
        }

        return back()->with('success', 'Alumno transferido correctamente');
    }

}
