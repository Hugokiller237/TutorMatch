<?php

namespace App\Http\Controllers;

use App\Models\Empresa;
use App\Models\Asignacion;
use Illuminate\Http\Request;

class EmpresaController extends Controller
{
    /**
     * Mostrar todas las empresas
     */
    public function index()
    {
        $empresas = Empresa::all();
        return view('listaEmpresas', compact('empresas'));
    }

    /**
     * Mostrar el formulario de creación
     */
    public function create()
    {
        return view('crearEmpresa');
    }

    /**
     * Guardar una nueva empresa
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:empresas,email',
            'representante_legal' => 'required|string|max:255',
            'telefono_representante_legal' => 'required|string|max:20',
            'dni_representante_legal' => 'required|string|max:20',
            'cif' => 'required|string|max:20',
            'tutor_laboral' => 'required|string|max:255',
            'dni_tutor_laboral' => 'required|string|max:20',
            'telefono_tutor_laboral' => 'required|string|max:20',
            'domicilio' => 'required|string|max:255',
        ]);

        Empresa::create($request->all());

        return redirect()->route('empresas.index')->with('success', 'Empresa creada correctamente');
    }

    /**
     * Mostrar el formulario de edición
     */
    public function edit($id)
    {
        $empresa = Empresa::findOrFail($id);
        return view('editarEmpresa', compact('empresa'));
    }

    /**
     * Actualizar una empresa
     */
    public function update(Request $request, $id)
    {
        $empresa = Empresa::findOrFail($id);

        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|email|unique:empresas,email,' . $empresa->id,
            'representante_legal' => 'required|string|max:255',
            'telefono_representante_legal' => 'required|string|max:20',
            'dni_representante_legal' => 'required|string|max:20',
            'cif' => 'required|string|max:20',
            'tutor_laboral' => 'required|string|max:255',
            'dni_tutor_laboral' => 'required|string|max:20',
            'telefono_tutor_laboral' => 'required|string|max:20',
            'domicilio' => 'required|string|max:255',
        ]);

        $empresa->update($request->all());

        return redirect()->route('empresas.index')->with('success', 'Empresa actualizada correctamente');
    }

    /**
     * Eliminar una empresa si no tiene asignaciones
     */
    public function destroy($id)
    {
        $empresa = Empresa::findOrFail($id);

        if ($empresa->asignaciones()->exists()) {
            return redirect()->back()->with('error', 'No se puede eliminar una empresa con asignaciones activas');
        }

        $empresa->delete();

        return redirect()->route('empresas.index')->with('success', 'Empresa eliminada correctamente');
    }
}
