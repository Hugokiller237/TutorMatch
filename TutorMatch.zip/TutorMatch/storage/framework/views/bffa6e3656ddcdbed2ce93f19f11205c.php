<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Asignar Empresa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 500px;
        }
    </style>
</head>

<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center py-4">

    <div class="form-container w-100 bg-white p-4 rounded shadow-sm">
        <h2 class="text-center fw-bold mb-3 text-success">Asignar Empresa</h2>

        <p class="text-center text-muted mb-4">
            Este formulario te permite asignar una empresa al alumno <strong><?php echo e($asignacion->alumno->nombre); ?></strong>.
        </p>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(url('/asignaciones/' . $asignacion->id . '/asignar')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <div class="mb-3">
                <label for="empresa_id" class="form-label">Selecciona una empresa</label>
                <select name="empresa_id" id="empresa_id" class="form-select" required>
                    <option value="" disabled selected>-- Selecciona una empresa --</option>
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($empresa->id); ?>" <?php echo e($asignacion->empresa_id == $empresa->id ? 'selected' : ''); ?>>
                            <?php echo e($empresa->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-success w-100">Guardar Asignación</button>
        </form>
        
        
        <?php if($asignacion->empresa_id): ?>
            <form action="<?php echo e(url('/asignaciones/' . $asignacion->id . '/asignar')); ?>" method="POST"
                onsubmit="return confirm('¿Estás seguro de que deseas quitar la empresa asignada?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>
                <input type="hidden" name="accion" value="quitar">
                <button type="submit" class="btn btn-danger w-100">Quitar Empresa</button>
            </form>
        <?php endif; ?>

        <div class="text-center mt-3">
            <a href="<?php echo e(url('/asignaciones')); ?>" class="text-decoration-none text-primary">← Volver a la lista</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/asignarEmpresa.blade.php ENDPATH**/ ?>