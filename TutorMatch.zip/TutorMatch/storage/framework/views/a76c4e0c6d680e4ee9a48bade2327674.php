<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section {
            max-width: 700px;
        }
        .form-image {
            background-color: #f0f4ff;
            padding: 2rem;
            border-radius: 0.5rem;
        }
    </style>
</head>
<body class="bg-light d-flex align-items-center min-vh-100 py-5">

    <div class="container">
        <div class="row justify-content-center align-items-center">
            
            <!-- Texto explicativo -->
            <div class="col-md-5 mb-4 mb-md-0 form-image">
                <h2 class="h4 fw-bold text-primary mb-3">Edita tu perfil</h2>
                <p class="text-muted">Aquí puedes modificar tu nombre, correo electrónico, actualizar tu contraseña o cambiar tu foto de perfil.</p>
                <p class="text-muted">Mantén tus datos actualizados para una mejor experiencia usando la aplicación.</p>
            </div>

            <!-- Formulario -->
            <div class="col-md-7">
                <div class="bg-white p-4 rounded shadow-sm form-section">
                    <h2 class="h5 text-center mb-4 text-dark fw-bold">Formulario de edición</h2>

                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(url('/tutor/actualizar')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control"
                                   value="<?php echo e(old('nombre', $tutor->nombre ?? '')); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Correo electrónico</label>
                            <input type="email" name="email" id="email" class="form-control"
                                   value="<?php echo e(old('email', $tutor->email ?? '')); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Nueva contraseña</label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="password_confirmation" class="form-label">Confirmar contraseña</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                        </div>

                        <div class="mb-4">
                            <label for="foto" class="form-label">Foto de perfil</label>
                            <input type="file" name="foto" id="foto" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Guardar cambios</button>
                    </form>

                    <div class="text-center mt-3">
                        <a href="<?php echo e(url('/')); ?>" class="text-decoration-none text-primary">&larr; Volver a la lista</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/editarPerfil.blade.php ENDPATH**/ ?>