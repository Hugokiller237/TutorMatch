<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Lista de Tutores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-light bg-light mb-4">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary mb-3">Volver</a>
            <form action="/logout" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Cerrar Sesión</button>
            </form>
        </div>
    </nav>

    <div class="container mt-4">

        
        <form method="GET" action="<?php echo e(route('tutores.index')); ?>" class="row g-2 mb-4">
            <div class="col-md-6">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar tutor por nombre"
                    value="<?php echo e(request('buscar')); ?>">
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
            <div class="col-md-auto">
                <a href="<?php echo e(route('tutores.index')); ?>" class="btn btn-secondary">Limpiar</a>
            </div>
        </form>

        <h2 class="mb-4">Lista de Tutores</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <a href="<?php echo e(route('tutores.create')); ?>" class="btn btn-success mb-3">Crear Nuevo Tutor</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tutores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tutor->nombre); ?></td>
                        <td><?php echo e($tutor->email); ?></td>
                        <td><?php echo e($tutor->rol); ?></td>
                        <td>
                            <a href="<?php echo e(route('tutores.edit', $tutor->id)); ?>" class="btn btn-primary btn-sm">Editar</a>
                            <a href="<?php echo e(route('tutores.alumnos', $tutor->id)); ?>" class="btn btn-info btn-sm">Ver Alumnos</a>

                            
                            <?php if($tutor->id !== $admin->id): ?>
                                <form action="<?php echo e(route('tutores.destroy', $tutor->id)); ?>" method="POST" style="display:inline;"
                                    onsubmit="return confirm('¿Seguro que deseas eliminar este tutor?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            <?php else: ?>
                                
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/listaTutores.blade.php ENDPATH**/ ?>