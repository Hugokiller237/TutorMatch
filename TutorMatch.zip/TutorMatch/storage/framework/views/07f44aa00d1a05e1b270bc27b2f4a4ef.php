<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Alumnos del Tutor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    <h1 class="mb-4">Alumnos del Tutor: <?php echo e($tutor->nombre); ?></h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php elseif(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('tutores.index')); ?>" class="btn btn-secondary mb-3">Volver</a>

    <?php if($alumnos->isEmpty()): ?>
        <p>No hay alumnos asignados a este tutor.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Curso Escolar</th>
                        <th>Año Escolar</th>
                        <th>Estancia</th>
                        <th>¿En empresa?</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if($alumno->foto): ?>
                                    <img src="<?php echo e(asset('fotos_alumnos/' . $alumno->foto)); ?>" alt="Foto Alumno" width="60"
                                        height="60" class="rounded-circle">
                                <?php else: ?>
                                    <span class="text-muted">Sin foto</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($alumno->nombre); ?></td>
                            <td><?php echo e($alumno->email); ?></td>
                            <td><?php echo e($alumno->curso_escolar); ?></td>
                            <td><?php echo e($alumno->anio_escolar); ?></td>
                            <td><?php echo e($alumno->tiempo_estancia); ?></td>
                            <td><?php echo e($alumno->en_empresa ? 'Sí' : 'No'); ?></td>
                            <td>
                                
                                <form action="<?php echo e(route('alumnos.transferir', $alumno->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <select name="nuevo_tutor_id" class="form-select form-select-sm d-inline w-auto" required>
                                        <option value="">Mover a...</option>
                                        <?php $__currentLoopData = $tutores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otroTutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($otroTutor->id !== $tutor->id): ?>
                                                <option value="<?php echo e($otroTutor->id); ?>"><?php echo e($otroTutor->nombre); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="btn btn-primary btn-sm">Mover</button>
                                </form>
                                <a href="<?php echo e(url('/alumnos/' . $alumno->id . '/editar')); ?>"
                                    class="btn btn-sm btn-warning">Editar</a>
                                <form action="<?php echo e(url('/alumnos/' . $alumno->id)); ?>" method="POST" class="d-inline"
                                    onsubmit="return confirm('¿Estás seguro de que deseas eliminar este alumno?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/alumnosDelTutor.blade.php ENDPATH**/ ?>