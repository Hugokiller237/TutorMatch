<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Empresas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-container {
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            padding: 2rem;
        }
        .header-bar {
            background-color: #ffffff;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
    </style>
</head>
<body class="bg-light">

    <!-- Encabezado -->
    <header class="header-bar d-flex justify-content-between align-items-center">
        <a href="/" class="text-decoration-none text-primary fw-bold">← Inicio</a>
        <a href="<?php echo e(route('empresas.create')); ?>" class="btn btn-success">+ Crear Empresa</a>
    </header>

    <!-- Contenido principal -->
    <main class="container py-5">
        <div class="table-container">
            <h1 class="h4 fw-bold mb-4 text-primary">Lista de Empresas</h1>

            
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Representante Legal</th>
                            <th>DNI Rep. Legal</th>
                            <th>Tel. Rep. Legal</th>
                            <th>CIF</th>
                            <th>Tutor Laboral</th>
                            <th>DNI Tutor</th>
                            <th>Tel. Tutor</th>
                            <th>Domicilio</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($empresa->nombre); ?></td>
                                <td><?php echo e($empresa->email); ?></td>
                                <td><?php echo e($empresa->representante_legal); ?></td>
                                <td><?php echo e($empresa->dni_representante_legal); ?></td>
                                <td><?php echo e($empresa->telefono_representante_legal); ?></td>
                                <td><?php echo e($empresa->cif); ?></td>
                                <td><?php echo e($empresa->tutor_laboral); ?></td>
                                <td><?php echo e($empresa->dni_tutor_laboral); ?></td>
                                <td><?php echo e($empresa->telefono_tutor_laboral); ?></td>
                                <td><?php echo e($empresa->domicilio); ?></td>
                                <td>
                                    <a href="<?php echo e(route('empresas.edit', $empresa->id)); ?>" class="btn btn-sm btn-outline-primary">Editar</a>

                                    <form action="<?php echo e(route('empresas.destroy', $empresa->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('¿Estás seguro de que quieres eliminar esta empresa?')">
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($empresas->isEmpty()): ?>
                            <tr>
                                <td colspan="11" class="text-center text-muted">No hay empresas registradas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/listaEmpresas.blade.php ENDPATH**/ ?>