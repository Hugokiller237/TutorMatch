<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Empresa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            padding: 2rem;
        }
    </style>
</head>
<body class="bg-light py-5">

    <div class="container">
        <div class="row justify-content-center align-items-center g-5">

            <!-- Texto explicativo -->
            <div class="col-lg-5">
                <h2 class="fw-bold text-success">Nueva Empresa</h2>
                <p class="text-muted">
                    Aquí puedes registrar una nueva empresa en el sistema. Introduce los datos necesarios como el nombre,
                    contacto, CIF y representantes para poder asociarla posteriormente a los alumnos.
                </p>
            </div>

            <!-- Formulario -->
            <div class="col-lg-6">
                <div class="form-container">
                    <form action="<?php echo e(route('empresas.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php
                            $fields = [
                                'nombre' => 'Nombre de la empresa',
                                'email' => 'Correo electrónico',
                                'representante_legal' => 'Nombre del representante legal',
                                'dni_representante_legal' => 'DNI del representante legal',
                                'telefono_representante_legal' => 'Teléfono del representante legal',
                                'cif' => 'CIF de la empresa',
                                'tutor_laboral' => 'Nombre del tutor laboral',
                                'dni_tutor_laboral' => 'DNI del tutor laboral',
                                'telefono_tutor_laboral' => 'Teléfono del tutor laboral',
                                'domicilio' => 'Domicilio',
                            ];
                        ?>

                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
                                <input type="text" name="<?php echo e($field); ?>" id="<?php echo e($field); ?>" class="form-control" value="<?php echo e(old($field)); ?>" required>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="d-flex justify-content-between mt-4">
                            <button type="submit" class="btn btn-success">Guardar</button>
                            <a href="<?php echo e(route('empresas.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/crearEmpresa.blade.php ENDPATH**/ ?>