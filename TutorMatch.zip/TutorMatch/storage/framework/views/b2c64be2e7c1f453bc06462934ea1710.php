<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - Tutor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">

    <div class="container">
        <div class="row justify-content-center align-items-center">

            <div class="col-md-6 mb-4">
                <div class="text-center">
                    <h1 class="display-5 fw-bold text-primary">Bienvenido a TutorMatch</h1>
                    <p class="lead text-secondary">
                        Esta plataforma te permite gestionar la asignación de tus alumnos a empresas
                        para la realización de prácticas profesionales. Inicia sesión para comenzar.
                    </p>
                </div>
            </div>

            <div class="col-md-5">
                <div class="card shadow-lg border-0">
                    <div class="card-body p-5">
                        <h2 class="h4 mb-4 text-center text-dark">Iniciar Sesión como Tutor</h2>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(url('/login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="email" class="form-label">Correo electrónico</label>
                                <input type="email" name="email" id="email" required
                                    class="form-control">
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label">Contraseña</label>
                                <input type="password" name="password" id="password" required
                                    class="form-control">
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    Iniciar Sesión
                                </button>
                            </div>
                        </form>
                        
                        <div class="mt-4 text-center">
                            <p class="mb-1">¿No tienes una cuenta?</p>
                            <a href="<?php echo e(url('/registrarse')); ?>" class="text-decoration-none text-primary fw-medium">
                                Registrarse como tutor
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/iniciarSesion.blade.php ENDPATH**/ ?>