<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrarse - Tutor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light d-flex align-items-center justify-center min-vh-100">

    <div class="container">
        <div class="row justify-content-center align-items-center">

            <div class="col-md-6 mb-4">
                <div class="text-center">
                    <h1 class="display-5 fw-bold text-primary">Únete a TutorMatch</h1>
                    <p class="lead text-secondary">
                        Crea tu cuenta como tutor y comienza a asignar alumnos a empresas fácilmente.
                        Organiza, gestiona y haz seguimiento de sus prácticas formativas.
                    </p>
                </div>
            </div>

            <div class="col-md-5">
                <div class="card shadow border-0">
                    <div class="card-body p-5">
                        <h2 class="h4 mb-4 text-center text-dark">Registro de Tutor</h2>

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(url('/registrarse')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre</label>
                                <input type="text" name="nombre" id="nombre" required class="form-control">
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Correo electrónico</label>
                                <input type="email" name="email" id="email" required class="form-control">
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Contraseña</label>
                                <input type="password" name="password" id="password" required class="form-control">
                            </div>

                            <div class="mb-3">
                                <label for="password_confirmation" class="form-label">Confirmar Contraseña</label>
                                <input type="password" name="password_confirmation" id="password_confirmation" required class="form-control">
                            </div>

                            <div class="mb-4">
                                <label for="foto" class="form-label">Foto de perfil</label>
                                <input type="file" name="foto" id="foto" accept="image/*" class="form-control">
                            </div>

                            <div class="d-grid">
                                <button type="submit" class="btn btn-success">
                                    Registrarse
                                </button>
                            </div>
                        </form>

                        <div class="mt-4 text-center">
                            <p class="mb-1">¿Ya tienes cuenta?</p>
                            <a href="<?php echo e(url('/iniciar-sesion')); ?>" class="text-decoration-none text-primary fw-medium">
                                Iniciar Sesión
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/registrarse.blade.php ENDPATH**/ ?>