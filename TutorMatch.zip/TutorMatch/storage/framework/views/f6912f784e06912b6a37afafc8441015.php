<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Lista de Asignaciones</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table th,
        .table td {
            vertical-align: middle;
        }

        .header-buttons .btn {
            margin-right: 0.5rem;
        }
    </style>
</head>

<body class="bg-light min-vh-100">

    <header class="bg-white shadow-sm py-3 mb-4">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="header-buttons d-flex flex-wrap">
                <a href="<?php echo e(url('/empresas')); ?>" class="btn btn-success">Empresas</a>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Volver</a>
            </div>
        </div>
    </header>

    <main class="container">
        <h2 class="fw-bold mb-4 text-success">Asignaciones</h2>

        <?php if($asignaciones->isEmpty()): ?>
            <div class="alert alert-info">No hay asignaciones disponibles.</div>
        <?php else: ?>
            <div class="table-responsive shadow-sm rounded">
                <table class="table table-bordered table-hover bg-white">
                    <thead class="table-light text-uppercase">
                        <tr>
                            <th>Alumno</th>
                            <th>Empresa</th>
                            <th>Fecha de Asignación</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($asignacion->alumno->nombre); ?></td>
                                <td><?php echo e($asignacion->empresa ? $asignacion->empresa->nombre : 'Sin asignar'); ?></td>
                                <td>
                                    <?php echo e($asignacion->fecha_asignacion ? \Carbon\Carbon::parse($asignacion->fecha_asignacion)->format('d/m/Y') : '-'); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(url('/asignaciones/' . $asignacion->id . '/asignar')); ?>"
                                        class="btn btn-sm btn-primary">Asignar Empresa</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/listaAsignaciones.blade.php ENDPATH**/ ?>