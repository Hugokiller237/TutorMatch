<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Mis Alumnos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .alumno-foto {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Header -->
    <header class="bg-white shadow-sm py-3 mb-4 border-bottom">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-3">
                <img src="<?php echo e(asset('fotos_tutores/' . $tutor->foto)); ?>" alt="Foto del tutor" class="alumno-foto border">
                <h1 class="h5 m-0 fw-bold text-primary">Bienvenido, <?php echo e($tutor->nombre); ?></h1>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                
                <a href="<?php echo e(url('/tutor/editar')); ?>" class="btn btn-outline-primary btn-sm">Editar Perfil</a>

                <?php
                    $tutor = \App\Models\Tutor::find(session('tutor_id'));
                ?>

                
                <?php if($tutor && $tutor->rol === 'admin'): ?>
                    <a href="<?php echo e(url('/tutores')); ?>" class="btn btn-outline-dark btn-sm">Gestión de Tutores</a>
                <?php endif; ?>

                
                <a href="<?php echo e(url('/alumnos/crear')); ?>" class="btn btn-outline-success btn-sm">Agregar Alumno</a>

                
                <a href="<?php echo e(url('/empresas')); ?>" class="btn btn-outline-info btn-sm">Empresas</a>

                
                <a href="<?php echo e(url('/asignaciones')); ?>" class="btn btn-outline-warning btn-sm">Asignaciones</a>

                
                <form action="<?php echo e(url('/logout')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-danger btn-sm">Cerrar Sesión</button>
                </form>
            </div>

        </div>
    </header>

    <!-- Main -->
    <div class="container">

        
        <form method="GET" action="<?php echo e(url('/')); ?>" class="row g-2 mb-4">
            <div class="col-md-6">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar alumno por nombre"
                    value="<?php echo e(request('buscar')); ?>">
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
            <div class="col-md-auto">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">Limpiar</a>
            </div>
        </form>

        
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle bg-white">
                <thead class="table-light">
                    <tr>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Curso</th>
                        <th>Año Escolar</th>
                        <th>Estancia</th>
                        <th>En Empresa</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php if($alumno->foto): ?>
                                    <img src="<?php echo e(asset('fotos_alumnos/' . $alumno->foto)); ?>" alt="Foto de <?php echo e($alumno->nombre); ?>"
                                        width="50" height="50" class="rounded-circle">
                                <?php else: ?>
                                    <span class="text-muted">Sin foto</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($alumno->nombre); ?></td>
                            <td><?php echo e($alumno->email); ?></td>
                            <td><?php echo e($alumno->curso_escolar); ?></td>
                            <td><?php echo e($alumno->anio_escolar); ?></td>
                            <td><?php echo e($alumno->tiempo_estancia); ?></td>
                            <td>
                                <?php if($alumno->en_empresa): ?>
                                    <span class="badge bg-success">Sí</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">No</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/alumnos/' . $alumno->id . '/editar')); ?>"
                                    class="btn btn-sm btn-warning">Editar</a>
                                <form action="<?php echo e(url('/alumnos/' . $alumno->id)); ?>" method="POST" class="d-inline"
                                    onsubmit="return confirm('¿Estás seguro de que deseas eliminar este alumno?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">No se encontraron alumnos.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\tutorMatch\TutorMatch\resources\views/listaAlumnos.blade.php ENDPATH**/ ?>