<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TutorController;
use App\Http\Controllers\AlumnoController;
use App\Http\Controllers\EmpresaController;
use App\Http\Controllers\AsignacionController;

Route::get('/', [AlumnoController::class, 'vistaLista']);
Route::view('/iniciar-sesion', 'iniciarSesion');
Route::view('/alumnos/crear', 'agregarAlumno');
Route::get('/tutor/editar', [TutorController::class, 'editar']);

//Tutores
Route::post('/login', [TutorController::class, 'login']);
Route::post('/logout', [TutorController::class, 'logout']);
Route::post('/tutor/actualizar', [TutorController::class, 'update']);
Route::get('/registrarse', [TutorController::class, 'showRegisterForm']);
Route::post('/registrarse', [TutorController::class, 'register']);

//Administrador
Route::middleware('web')->group(function () {
    Route::get('/tutores', [TutorController::class, 'index'])->name('tutores.index');
    Route::get('/tutores/crear', [TutorController::class, 'create'])->name('tutores.create');
    Route::post('/tutores', [TutorController::class, 'store'])->name('tutores.store');
    Route::get('/tutores/{id}/editar', [TutorController::class, 'edit'])->name('tutores.edit');
    Route::put('/tutores/{id}', [TutorController::class, 'updateAdmin'])->name('tutores.update');
    Route::delete('/tutores/{id}', [TutorController::class, 'destroy'])->name('tutores.destroy');
    Route::get('/tutores/{id}/alumnos', [TutorController::class, 'verAlumnos'])->name('tutores.alumnos');
});

Route::middleware('web')->group(function () {
    // Alumnos
    Route::get('/alumnos', [AlumnoController::class, 'index']);
    Route::post('/alumnos', [AlumnoController::class, 'store']);
    Route::delete('/alumnos/{id}', [AlumnoController::class, 'destroy'])->name('alumnos.destroy');
    Route::get('/alumnos/{id}/editar', [AlumnoController::class, 'edit'])->name('alumnos.edit');
    Route::put('/alumnos/{id}', [AlumnoController::class, 'update'])->name('alumnos.update');
    Route::post('/alumnos/{id}/transferir', [AlumnoController::class, 'transferir'])->name('alumnos.transferir');


    // Empresas
    Route::get('/empresas', [EmpresaController::class, 'index'])->name('empresas.index');
    Route::get('/empresas/crear', [EmpresaController::class, 'create'])->name('empresas.create');
    Route::post('/empresas', [EmpresaController::class, 'store'])->name('empresas.store');
    Route::get('/empresas/{id}/editar', [EmpresaController::class, 'edit'])->name('empresas.edit');
    Route::put('/empresas/{id}', [EmpresaController::class, 'update'])->name('empresas.update');
    Route::delete('/empresas/{id}', [EmpresaController::class, 'destroy'])->name('empresas.destroy');
});

Route::middleware('web')->group(function () {

    Route::get('/asignaciones', [AsignacionController::class, 'vistaLista'])->name('asignaciones.index');
    Route::get('/asignaciones/{id}/asignar', [AsignacionController::class, 'formAsignar'])->name('asignaciones.form');
    Route::post('/asignaciones/{id}/asignar', [AsignacionController::class, 'asignarEmpresa'])->name('asignaciones.asignar');
});
