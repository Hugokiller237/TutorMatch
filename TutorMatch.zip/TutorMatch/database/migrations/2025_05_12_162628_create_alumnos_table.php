<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAlumnosTable extends Migration
{
    public function up()
    {
        Schema::create('alumnos', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->string('email')->unique();
            $table->string('foto')->nullable();
            $table->unsignedBigInteger('tutor_id');
            $table->enum('curso_escolar', [
                '1 SMR', '2 SMR',
                '1 ASIR', '2 ASIR',
                '1 DAW', '2 DAW',
                '1 DAM', '2 DAM'
            ]);
            $table->string('anio_escolar');
            $table->string('tiempo_estancia');
            $table->boolean('en_empresa')->default(false);
            $table->foreign('tutor_id')->references('id')->on('tutores')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('alumnos');
    }
}
