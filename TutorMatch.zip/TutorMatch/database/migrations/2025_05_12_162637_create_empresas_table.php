<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmpresasTable extends Migration
{
    public function up()
    {
        Schema::create('empresas', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->string('email')->unique();
            $table->string('representante_legal');
            $table->string('telefono_representante_legal');
            $table->string('dni_representante_legal');
            $table->string('cif');
            $table->string('tutor_laboral');
            $table->string('dni_tutor_laboral');
            $table->string('telefono_tutor_laboral');
            $table->string('domicilio');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('empresas');
    }
}
