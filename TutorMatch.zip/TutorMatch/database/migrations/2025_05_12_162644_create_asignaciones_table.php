<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAsignacionesTable extends Migration
{
    public function up()
    {
        Schema::create('asignaciones', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('alumno_id');
            $table->unsignedBigInteger('empresa_id')->nullable(); // Puede estar vacío
            $table->unsignedBigInteger('tutor_id');
            $table->date('fecha_asignacion')->nullable();
            $table->timestamps();

            $table->foreign('alumno_id')->references('id')->on('alumnos')->onDelete('cascade');
            $table->foreign('empresa_id')->references('id')->on('empresas')->onDelete('set null');
            $table->foreign('tutor_id')->references('id')->on('tutores')->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::dropIfExists('asignaciones');
    }
}

