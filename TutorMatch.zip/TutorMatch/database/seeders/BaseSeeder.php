<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use App\Models\Tutor;
use App\Models\Alumno;
use App\Models\Empresa;
use App\Models\Asignacion;

class BaseSeeder extends Seeder
{
    public function run()
    {
        $rutaOrigen = public_path('fotos_tutores/ejemplo.png');
        $rutaDestino = public_path('fotos_alumnos/ejemplo.png');

        if (!File::exists($rutaDestino)) {
            File::copy($rutaOrigen, $rutaDestino);
        }

        // Crear 3 tutores
        $tutores = [
            [
                'nombre' => 'Hugo',
                'email' => 'hugo@gmail.com',
                'rol' => 'admin',
            ],
            [
                'nombre' => 'Ana Torres',
                'email' => 'ana.torres@example.com',
                'rol' => 'normal',
            ],
            [
                'nombre' => 'Carlos Ruiz',
                'email' => 'carlos.ruiz@example.com',
                'rol' => 'normal',
            ],
        ];

        foreach ($tutores as $tutorData) {
            $tutor = Tutor::create([
                'nombre' => $tutorData['nombre'],
                'email' => $tutorData['email'],
                'password' => Hash::make('pass123'),
                'rol' => $tutorData['rol'],
                'foto' => 'ejemplo.png',
            ]);

            // Crear 3 alumnos por tutor
            for ($i = 1; $i <= 3; $i++) {
                $alumno = Alumno::create([
                    'nombre' => $tutor->nombre . " Alumno $i",
                    'email' => Str::slug($tutor->nombre) . ".alumno$i@example.com",
                    'foto' => 'ejemplo.png',
                    'tutor_id' => $tutor->id,
                    'curso_escolar' => '1 DAW',
                    'anio_escolar' => '2024-2025',
                    'tiempo_estancia' => '3 meses',
                    'en_empresa' => false,
                ]);

                // Asignación sin empresa
                Asignacion::create([
                    'alumno_id' => $alumno->id,
                    'tutor_id' => $tutor->id,
                    'empresa_id' => null,
                    'fecha_asignacion' => null,
                ]);
            }
        }
    /*    DB::table('empresas')->insert([
            'nombre' => 'Innovatech S.L.',
            'email' => 'contacto@innovatech.com',
            'representante_legal' => 'Luis Mendoza',
            'telefono_representante_legal' => '600123456',
            'dni_representante_legal' => '12345678A',
            'cif' => 'B12345678',
            'tutor_laboral' => 'Marta López',
            'dni_tutor_laboral' => '23456789B',
            'telefono_tutor_laboral' => '611223344',
            'domicilio' => 'Calle Futura 123, Madrid',
        ]);
*/
        // Crear 3 empresas
        Empresa::create([
            'nombre' => 'Innovatech S.L.',
            'email' => 'contacto@innovatech.com',
            'representante_legal' => 'Luis Mendoza',
            'telefono_representante_legal' => '600123456',
            'dni_representante_legal' => '12345678A',
            'cif' => 'B12345678',
            'tutor_laboral' => 'Marta López',
            'dni_tutor_laboral' => '23456789B',
            'telefono_tutor_laboral' => '611223344',
            'domicilio' => 'Calle Futura 123, Madrid',
        ]);

        Empresa::create([
            'nombre' => 'Techify Group',
            'email' => 'info@techify.com',
            'representante_legal' => 'Ana Gómez',
            'telefono_representante_legal' => '622334455',
            'dni_representante_legal' => '34567890C',
            'cif' => 'B23456789',
            'tutor_laboral' => 'José Martín',
            'dni_tutor_laboral' => '45678901D',
            'telefono_tutor_laboral' => '633445566',
            'domicilio' => 'Avenida Tecnología 55, Barcelona',
        ]);

        Empresa::create([
            'nombre' => 'Digital Creators',
            'email' => 'hola@digitalcreators.com',
            'representante_legal' => 'María Pérez',
            'telefono_representante_legal' => '644556677',
            'dni_representante_legal' => '56789012E',
            'cif' => 'B34567890',
            'tutor_laboral' => 'Carlos Navarro',
            'dni_tutor_laboral' => '67890123F',
            'telefono_tutor_laboral' => '655667788',
            'domicilio' => 'Calle Creativa 88, Valencia',
        ]);
    }
}
