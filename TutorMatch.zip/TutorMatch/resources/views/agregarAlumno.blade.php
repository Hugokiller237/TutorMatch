<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Agregar Alumno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section {
            max-width: 700px;
        }

        .info-box {
            background-color: #f0f4ff;
            padding: 2rem;
            border-radius: 0.5rem;
        }
    </style>
</head>

<body class="bg-light d-flex align-items-center min-vh-100 py-5">

    <div class="container">
        <div class="row justify-content-center align-items-center">

            <!-- Texto informativo -->
            <div class="col-md-5 mb-4 mb-md-0 info-box">
                <h2 class="h4 fw-bold text-primary mb-3">Agregar un nuevo alumno</h2>
                <p class="text-muted">Rellena el siguiente formulario para añadir un alumno al sistema. Podrás
                    especificar sus datos personales, el curso, año escolar y el tiempo de estancia.</p>
                <p class="text-muted">Si lo deseas, también puedes subir una foto del alumno.</p>
            </div>

            <!-- Formulario -->
            <div class="col-md-7">
                <div class="bg-white p-4 rounded shadow-sm form-section">
                    <h2 class="h5 text-center mb-4 text-dark fw-bold">Formulario de alumno</h2>

                    {{-- Mostrar errores --}}
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ url('/alumnos') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre del alumno</label>
                            <input type="text" name="nombre" id="nombre" required class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Correo electrónico</label>
                            <input type="email" name="email" id="email" required class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="foto" class="form-label">Foto (opcional)</label>
                            <input type="file" name="foto" id="foto" accept="image/*" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="curso_escolar" class="form-label">Curso escolar</label>
                            <select name="curso_escolar" id="curso_escolar" required class="form-select">
                                <option value="">Selecciona un curso</option>
                                <option value="1 SMR">1 SMR</option>
                                <option value="2 SMR">2 SMR</option>
                                <option value="1 ASIR">1 ASIR</option>
                                <option value="2 ASIR">2 ASIR</option>
                                <option value="1 DAW">1 DAW</option>
                                <option value="2 DAW">2 DAW</option>
                                <option value="1 DAM">1 DAM</option>
                                <option value="2 DAM">2 DAM</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="anio_escolar" class="form-label">Año escolar (ej. 2024-2025)</label>
                            <input type="text" name="anio_escolar" id="anio_escolar" required class="form-control">
                        </div>

                        <div class="mb-4">
                            <label for="tiempo_estancia" class="form-label">Tiempo de estancia</label>
                            <input type="text" name="tiempo_estancia" id="tiempo_estancia" required
                                class="form-control">
                        </div>
                        @php
                            $tutorSesion = \App\Models\Tutor::find(session('tutor_id'));
                        @endphp

                        @if ($tutorSesion && $tutorSesion->rol === 'admin')
                            <div class="mb-3">
                                <label for="tutor_id" class="form-label">Asignar a tutor</label>
                                <select name="tutor_id" id="tutor_id" class="form-select" required>
                                    <option value="">Selecciona un tutor</option>
                                    @foreach (\App\Models\Tutor::all() as $t)
                                        <option value="{{ $t->id }}">{{ $t->nombre }} ({{ $t->email }})</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif

                        <button type="submit" class="btn btn-primary w-100">Guardar Alumno</button>
                    </form>

                    <div class="text-center mt-3">
                        <a href="{{ url('/') }}" class="text-decoration-none text-primary">&larr; Volver a la lista</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>