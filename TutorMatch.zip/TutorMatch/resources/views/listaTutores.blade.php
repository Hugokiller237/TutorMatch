<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Lista de Tutores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-light bg-light mb-4">
        <div class="container">
            <a href="{{ url('/') }}" class="btn btn-secondary mb-3">Volver</a>
            <form action="/logout" method="POST" class="d-inline">
                @csrf
                <button type="submit" class="btn btn-danger">Cerrar Sesión</button>
            </form>
        </div>
    </nav>

    <div class="container mt-4">

        {{-- Buscador --}}
        <form method="GET" action="{{ route('tutores.index') }}" class="row g-2 mb-4">
            <div class="col-md-6">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar tutor por nombre"
                    value="{{ request('buscar') }}">
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
            <div class="col-md-auto">
                <a href="{{ route('tutores.index') }}" class="btn btn-secondary">Limpiar</a>
            </div>
        </form>

        <h2 class="mb-4">Lista de Tutores</h2>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <a href="{{ route('tutores.create') }}" class="btn btn-success mb-3">Crear Nuevo Tutor</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tutores as $tutor)
                    <tr>
                        <td>{{ $tutor->nombre }}</td>
                        <td>{{ $tutor->email }}</td>
                        <td>{{ $tutor->rol }}</td>
                        <td>
                            <a href="{{ route('tutores.edit', $tutor->id) }}" class="btn btn-primary btn-sm">Editar</a>
                            <a href="{{ route('tutores.alumnos', $tutor->id) }}" class="btn btn-info btn-sm">Ver Alumnos</a>

                            {{-- Solo mostrar el botón de eliminar si no eres tú mismo --}}
                            @if($tutor->id !== $admin->id)
                                <form action="{{ route('tutores.destroy', $tutor->id) }}" method="POST" style="display:inline;"
                                    onsubmit="return confirm('¿Seguro que deseas eliminar este tutor?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            @else
                                
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>

</html>