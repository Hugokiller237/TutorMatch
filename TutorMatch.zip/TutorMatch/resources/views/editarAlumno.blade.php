<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Alumno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section {
            max-width: 700px;
        }
        .form-image {
            background-color: #f0f4ff;
            padding: 2rem;
            border-radius: 0.5rem;
        }
    </style>
</head>
<body class="bg-light d-flex align-items-center min-vh-100 py-5">

    <div class="container">
        <div class="row justify-content-center align-items-center">
            
            <!-- Texto explicativo -->
            <div class="col-md-5 mb-4 mb-md-0 form-image">
                <h2 class="h4 fw-bold text-primary mb-3">Edita los datos del alumno</h2>
                <p class="text-muted">Puedes actualizar la información personal del alumno, su curso, año escolar, o cambiar su fotografía si lo necesitas.</p>
                <p class="text-muted">Los cambios se guardarán inmediatamente tras confirmar el formulario.</p>
            </div>

            <!-- Formulario -->
            <div class="col-md-7">
                <div class="bg-white p-4 rounded shadow-sm form-section">
                    <h2 class="h5 text-center mb-4 text-dark fw-bold">Formulario de edición</h2>

                    {{-- Errores --}}
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    {{-- Mensaje de éxito --}}
                    @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    <form action="{{ route('alumnos.update', $alumno->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre</label>
                            <input type="text" name="nombre" id="nombre" class="form-control"
                                   value="{{ old('nombre', $alumno->nombre) }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Correo electrónico</label>
                            <input type="email" name="email" id="email" class="form-control"
                                   value="{{ old('email', $alumno->email) }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="curso_escolar" class="form-label">Curso escolar</label>
                            <select name="curso_escolar" id="curso_escolar" class="form-select" required>
                                @foreach(['1 SMR','2 SMR','1 ASIR','2 ASIR','1 DAW','2 DAW','1 DAM','2 DAM'] as $curso)
                                    <option value="{{ $curso }}" @selected($alumno->curso_escolar === $curso)>{{ $curso }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="anio_escolar" class="form-label">Año escolar (ej: 2024-2025)</label>
                            <input type="text" name="anio_escolar" id="anio_escolar" class="form-control"
                                   value="{{ old('anio_escolar', $alumno->anio_escolar) }}" required>
                        </div>

                        <div class="mb-3">
                            <label for="tiempo_estancia" class="form-label">Tiempo de estancia</label>
                            <input type="text" name="tiempo_estancia" id="tiempo_estancia" class="form-control"
                                   value="{{ old('tiempo_estancia', $alumno->tiempo_estancia) }}" required>
                        </div>

                        <div class="mb-4">
                            <label for="foto" class="form-label">Foto del alumno (opcional)</label>
                            <input type="file" name="foto" id="foto" class="form-control">
                            @if($alumno->foto)
                                <div class="mt-2">
                                    <img src="{{ asset('fotos_alumnos/' . $alumno->foto) }}" alt="Foto actual" class="img-thumbnail" width="120">
                                </div>
                            @endif
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Guardar cambios</button>
                    </form>

                    <div class="text-center mt-3">
                        <a href="{{ url('/') }}" class="text-decoration-none text-primary">&larr; Volver a la lista</a>
                    </div>
                </div>
            </div>
