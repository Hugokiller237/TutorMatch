<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Mis Alumnos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .alumno-foto {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
        }
    </style>
</head>

<body class="bg-light">

    <!-- Header -->
    <header class="bg-white shadow-sm py-3 mb-4 border-bottom">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-3">
                <img src="{{ asset('fotos_tutores/' . $tutor->foto) }}" alt="Foto del tutor" class="alumno-foto border">
                <h1 class="h5 m-0 fw-bold text-primary">Bienvenido, {{ $tutor->nombre }}</h1>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                {{-- Editar perfil --}}
                <a href="{{ url('/tutor/editar') }}" class="btn btn-outline-primary btn-sm">Editar Perfil</a>

                @php
                    $tutor = \App\Models\Tutor::find(session('tutor_id'));
                @endphp

                {{-- Gestión de tutores (solo admin) --}}
                @if ($tutor && $tutor->rol === 'admin')
                    <a href="{{ url('/tutores') }}" class="btn btn-outline-dark btn-sm">Gestión de Tutores</a>
                @endif

                {{-- Agregar alumno --}}
                <a href="{{ url('/alumnos/crear') }}" class="btn btn-outline-success btn-sm">Agregar Alumno</a>

                {{-- Empresas --}}
                <a href="{{ url('/empresas') }}" class="btn btn-outline-info btn-sm">Empresas</a>

                {{-- Asignaciones --}}
                <a href="{{ url('/asignaciones') }}" class="btn btn-outline-warning btn-sm">Asignaciones</a>

                {{-- Cerrar sesión --}}
                <form action="{{ url('/logout') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-danger btn-sm">Cerrar Sesión</button>
                </form>
            </div>

        </div>
    </header>

    <!-- Main -->
    <div class="container">

        {{-- Buscador --}}
        <form method="GET" action="{{ url('/') }}" class="row g-2 mb-4">
            <div class="col-md-6">
                <input type="text" name="buscar" class="form-control" placeholder="Buscar alumno por nombre"
                    value="{{ request('buscar') }}">
            </div>
            <div class="col-md-auto">
                <button type="submit" class="btn btn-primary">Buscar</button>
            </div>
            <div class="col-md-auto">
                <a href="{{ url('/') }}" class="btn btn-secondary">Limpiar</a>
            </div>
        </form>

        {{-- Tabla de alumnos --}}
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle bg-white">
                <thead class="table-light">
                    <tr>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Curso</th>
                        <th>Año Escolar</th>
                        <th>Estancia</th>
                        <th>En Empresa</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($alumnos as $alumno)
                        <tr>
                            <td>
                                @if ($alumno->foto)
                                    <img src="{{ asset('fotos_alumnos/' . $alumno->foto) }}" alt="Foto de {{ $alumno->nombre }}"
                                        width="50" height="50" class="rounded-circle">
                                @else
                                    <span class="text-muted">Sin foto</span>
                                @endif
                            </td>
                            <td>{{ $alumno->nombre }}</td>
                            <td>{{ $alumno->email }}</td>
                            <td>{{ $alumno->curso_escolar }}</td>
                            <td>{{ $alumno->anio_escolar }}</td>
                            <td>{{ $alumno->tiempo_estancia }}</td>
                            <td>
                                @if ($alumno->en_empresa)
                                    <span class="badge bg-success">Sí</span>
                                @else
                                    <span class="badge bg-secondary">No</span>
                                @endif
                            </td>
                            <td>
                                <a href="{{ url('/alumnos/' . $alumno->id . '/editar') }}"
                                    class="btn btn-sm btn-warning">Editar</a>
                                <form action="{{ url('/alumnos/' . $alumno->id) }}" method="POST" class="d-inline"
                                    onsubmit="return confirm('¿Estás seguro de que deseas eliminar este alumno?');">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted">No se encontraron alumnos.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>