<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Empresa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            padding: 2rem;
        }
    </style>
</head>
<body class="bg-light py-5">

    <div class="container">
        <div class="row justify-content-center align-items-center g-5">

            <!-- Texto explicativo -->
            <div class="col-lg-5">
                <div class="mb-4">
                    <h2 class="fw-bold text-primary">Editar Empresa</h2>
                    <p class="text-muted">
                        En este formulario puedes modificar la información de la empresa seleccionada.
                        Asegúrate de completar todos los campos correctamente antes de guardar los cambios.
                    </p>
                </div>
            </div>

            <!-- Formulario -->
            <div class="col-lg-6">
                <div class="form-container">
                    <form action="{{ route('empresas.update', $empresa->id) }}" method="POST">
                        @csrf
                        @method('PUT')

                        @php
                            $fields = [
                                'nombre' => 'Nombre de la empresa',
                                'email' => 'Correo electrónico',
                                'representante_legal' => 'Nombre del representante legal',
                                'dni_representante_legal' => 'DNI del representante legal',
                                'telefono_representante_legal' => 'Teléfono del representante legal',
                                'cif' => 'CIF de la empresa',
                                'tutor_laboral' => 'Nombre del tutor laboral',
                                'dni_tutor_laboral' => 'DNI del tutor laboral',
                                'telefono_tutor_laboral' => 'Teléfono del tutor laboral',
                                'domicilio' => 'Domicilio',
                            ];
                        @endphp

                        @foreach ($fields as $field => $label)
                            <div class="mb-3">
                                <label for="{{ $field }}" class="form-label">{{ $label }}</label>
                                <input type="text" name="{{ $field }}" id="{{ $field }}"
                                    value="{{ old($field, $empresa->$field) }}"
                                    class="form-control" required>
                            </div>
                        @endforeach

                        <div class="d-flex justify-content-between mt-4">
                            <button type="submit" class="btn btn-primary">Actualizar</button>
                            <a href="{{ route('empresas.index') }}" class="btn btn-outline-secondary">Cancelar</a>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
