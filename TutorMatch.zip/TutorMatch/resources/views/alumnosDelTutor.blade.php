<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Alumnos del Tutor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container py-4">

    <h1 class="mb-4">Alumnos del Tutor: {{ $tutor->nombre }}</h1>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @elseif(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <a href="{{ route('tutores.index') }}" class="btn btn-secondary mb-3">Volver</a>

    @if($alumnos->isEmpty())
        <p>No hay alumnos asignados a este tutor.</p>
    @else
        <div class="table-responsive">
            <table class="table table-striped table-bordered align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Email</th>
                        <th>Curso Escolar</th>
                        <th>Año Escolar</th>
                        <th>Estancia</th>
                        <th>¿En empresa?</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($alumnos as $alumno)
                        <tr>
                            <td>
                                @if($alumno->foto)
                                    <img src="{{ asset('fotos_alumnos/' . $alumno->foto) }}" alt="Foto Alumno" width="60"
                                        height="60" class="rounded-circle">
                                @else
                                    <span class="text-muted">Sin foto</span>
                                @endif
                            </td>
                            <td>{{ $alumno->nombre }}</td>
                            <td>{{ $alumno->email }}</td>
                            <td>{{ $alumno->curso_escolar }}</td>
                            <td>{{ $alumno->anio_escolar }}</td>
                            <td>{{ $alumno->tiempo_estancia }}</td>
                            <td>{{ $alumno->en_empresa ? 'Sí' : 'No' }}</td>
                            <td>
                                {{-- Formulario Mover a otro tutor --}}
                                <form action="{{ route('alumnos.transferir', $alumno->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    <select name="nuevo_tutor_id" class="form-select form-select-sm d-inline w-auto" required>
                                        <option value="">Mover a...</option>
                                        @foreach($tutores as $otroTutor)
                                            @if($otroTutor->id !== $tutor->id)
                                                <option value="{{ $otroTutor->id }}">{{ $otroTutor->nombre }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                    <button class="btn btn-primary btn-sm">Mover</button>
                                </form>
                                <a href="{{ url('/alumnos/' . $alumno->id . '/editar') }}"
                                    class="btn btn-sm btn-warning">Editar</a>
                                <form action="{{ url('/alumnos/' . $alumno->id) }}" method="POST" class="d-inline"
                                    onsubmit="return confirm('¿Estás seguro de que deseas eliminar este alumno?');">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif

</body>

</html>